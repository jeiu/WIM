package wim;

import java.util.Scanner;
public class Guajae01
{
 public static void main(String[] args)
 {
  Scanner scan = new Scanner(System.in);
  int pro;
  int num;
  
  System.out.println("===========================================" );
  System.out.println("1.구입 금액 확인 " + "2. 판매 금액 확인");
  System.out.println("-------------------------------------------" );
  System.out.print("@ 상품번호 : " );
  pro = scan.nextInt();
  System.out.print("@ 판매수량 : " );
  num = scan.nextInt();
  System.out.println("-------------------------------------------" );
    
  if (pro == 1)
  {
  System.out.println("상품명 : " + pro + " 매출 : " + (num*1000));
    }
  else if (pro == 2)
  {
  System.out.println("상품명 : " + pro + " 매출 : " + (num*5500));
    }
  else
  {
  System.out.println("바부탱이!! 반성 좀 해봐봐~ " );
    }
  System.out.println("===========================================" );
 }
}
